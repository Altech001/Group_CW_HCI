package utils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.net.URL;

/**
 * Utility class for handling icons and UI components with modern light theme styling
 */
public class IconUtils {
    
    /**
     * Load an ImageIcon from the resources directory
     */
    public static ImageIcon loadIcon(String path, int width, int height) {
        try {
            // Try loading from classpath first
            URL resource = IconUtils.class.getClassLoader().getResource(path);
            if (resource != null) {
                ImageIcon icon = new ImageIcon(resource);
                if (width > 0 && height > 0) {
                    Image scaled = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                    return new ImageIcon(scaled);
                }
                return icon;
            }
            
            // Fallback to file system
            File file = new File(path);
            if (file.exists()) {
                ImageIcon icon = new ImageIcon(path);
                if (width > 0 && height > 0) {
                    Image scaled = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                    return new ImageIcon(scaled);
                }
                return icon;
            }
        } catch (Exception e) {
            System.err.println("Error loading icon from " + path + ": " + e.getMessage());
        }
        return null;
    }
    
    /**
     * Creates a styled button with an icon and text
     */
    public static JButton createStyledButton(String text, String iconPath, Dimension buttonSize) {
        JButton button = new JButton(text);
        ImageIcon icon = loadIcon(iconPath, 16, 16);
        if (icon != null) {
            button.setIcon(icon);
        }
        
        button.setPreferredSize(buttonSize);
        button.setBackground(Constants.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        button.setFont(Constants.REGULAR_FONT);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        return button;
    }
    
    /**
     * Creates a styled panel with rounded corners and optional shadow
     */
    public static JPanel createRoundedPanel(Color bgColor, int radius) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw shadow
                g2d.setColor(new Color(0, 0, 0, 10));
                g2d.fill(new RoundRectangle2D.Float(2, 2, getWidth() - 4, getHeight() - 4, radius, radius));
                
                // Draw background
                g2d.setColor(bgColor);
                g2d.fill(new RoundRectangle2D.Float(0, 0, getWidth() - 2, getHeight() - 2, radius, radius));
                
                g2d.dispose();
            }
        };
    }
    
    /**
     * Creates a styled header label
     */
    public static JLabel createHeaderLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(Constants.HEADER_FONT);
        label.setForeground(Constants.TEXT_COLOR);
        label.setBorder(new EmptyBorder(12, 12, 12, 12));
        return label;
    }
    
    /**
     * Creates a styled subheader label
     */
    public static JLabel createSubHeaderLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(Constants.SUBHEADER_FONT);
        label.setForeground(Constants.TEXT_COLOR);
        label.setBorder(new EmptyBorder(8, 8, 8, 8));
        return label;
    }
    
    /**
     * Styles a JTable with modern light theme
     */
    public static void styleTable(JTable table) {
        table.setRowHeight(Constants.TABLE_ROW_HEIGHT);
        table.setIntercellSpacing(new Dimension(10, 5));
        table.setGridColor(Constants.TABLE_BORDER_COLOR);
        table.setSelectionBackground(Constants.PRIMARY_COLOR);
        table.setSelectionForeground(Color.WHITE);
        table.setFont(Constants.REGULAR_FONT);
        table.setShowVerticalLines(false);
        
        // Style header
        table.getTableHeader().setBackground(Constants.TABLE_HEADER_COLOR);
        table.getTableHeader().setFont(Constants.SUBHEADER_FONT);
        table.getTableHeader().setForeground(Constants.TEXT_COLOR);
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Constants.TABLE_BORDER_COLOR));
        
        // Alternating row colors
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Constants.TABLE_ROW_COLOR : Constants.TABLE_ALTERNATE_ROW_COLOR);
                    c.setForeground(Constants.TEXT_COLOR);
                }
                
                // Add padding to cells
                setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
                
                return c;
            }
        };
        
        table.setDefaultRenderer(Object.class, renderer);
    }
    
    /**
     * Creates a scroll pane with modern styling
     */
    public static JScrollPane createStyledScrollPane(Component component) {
        JScrollPane scrollPane = new JScrollPane(component);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Constants.BACKGROUND_COLOR);
        
        // Style scrollbars with custom colors
        JScrollBar verticalScrollBar = scrollPane.getVerticalScrollBar();
        JScrollBar horizontalScrollBar = scrollPane.getHorizontalScrollBar();
        
        verticalScrollBar.setUI(new ModernScrollBarUI());
        horizontalScrollBar.setUI(new ModernScrollBarUI());
        
        verticalScrollBar.setPreferredSize(new Dimension(8, 0));
        horizontalScrollBar.setPreferredSize(new Dimension(0, 8));
        
        return scrollPane;
    }
    
    /**
     * Modern scroll bar UI
     */
    private static class ModernScrollBarUI extends BasicScrollBarUI {
        private final Color thumbColor = Constants.PRIMARY_COLOR;
        private final Color trackColor = Constants.BACKGROUND_COLOR;
        
        @Override
        protected void configureScrollBarColors() {
            // No custom colors needed here since we're overriding the paint methods
        }
        
        @Override
        protected JButton createDecreaseButton(int orientation) {
            return createZeroButton();
        }
        
        @Override
        protected JButton createIncreaseButton(int orientation) {
            return createZeroButton();
        }
        
        private JButton createZeroButton() {
            JButton button = new JButton();
            button.setPreferredSize(new Dimension(0, 0));
            button.setMinimumSize(new Dimension(0, 0));
            button.setMaximumSize(new Dimension(0, 0));
            return button;
        }
        
        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
            if (thumbBounds.isEmpty()) {
                return;
            }
            
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            g2.setColor(thumbColor);
            g2.fill(new RoundRectangle2D.Double(
                thumbBounds.x, thumbBounds.y,
                thumbBounds.width, thumbBounds.height,
                Constants.BORDER_RADIUS * 2, Constants.BORDER_RADIUS * 2));
            
            g2.dispose();
        }
        
        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            g2.setColor(trackColor);
            g2.fill(trackBounds);
            
            g2.dispose();
        }
    }
}
