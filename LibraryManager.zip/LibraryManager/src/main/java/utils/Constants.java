package utils;

import java.awt.*;

/**
 * Constants used throughout the application with a modern light theme
 */
public class Constants {
    // Application constants
    public static final String APP_TITLE = "VU Library MS";
    public static final Dimension APP_SIZE = new Dimension(1024, 768);
    public static final int LOAN_DURATION_DAYS = 14;
    public static final double FINE_PER_DAY = 0.5;

    // Modern light color scheme
    public static final Color PRIMARY_COLOR = new Color(37, 99, 235);     // Blue-700
    public static final Color ACCENT_COLOR = new Color(79, 70, 229);      // Indigo-700
    public static final Color BACKGROUND_COLOR = new Color(243, 244, 246); // Gray-100
    public static final Color SECONDARY_BACKGROUND = new Color(255, 255, 255); // White
    public static final Color TEXT_COLOR = new Color(17, 24, 39);         // Gray-900
    public static final Color SECONDARY_TEXT_COLOR = new Color(75, 85, 99); // Gray-600
    public static final Color INPUT_BORDER_COLOR = new Color(209, 213, 219); // Gray-300
    public static final Color INPUT_FOCUS_BORDER_COLOR = new Color(37, 99, 235); // Blue-700
    public static final Color HOVER_BACKGROUND = new Color(249, 250, 251); // Gray-50

    // Additional colors for enhanced UI
    public static final Color SIDEBAR_BACKGROUND = new Color(30, 41, 55);  // Gray-800
    public static final Color SIDEBAR_HOVER = new Color(55, 65, 81);      // Gray-700
    public static final Color SIDEBAR_ACTIVE = new Color(79, 70, 229);    // Indigo-600
    public static final Color CARD_BACKGROUND = new Color(255, 255, 255); // White
    public static final Color CARD_SHADOW = new Color(0, 0, 0, 10);      // 10% black
    public static final Color CARD_BORDER = new Color(229, 231, 235);    // Gray-200
    public static final Color SUCCESS_COLOR = new Color(34, 197, 94);    // Green-500
    public static final Color WARNING_COLOR = new Color(234, 179, 8);    // Yellow-500
    public static final Color DANGER_COLOR = new Color(239, 68, 68);     // Red-500

    // Font settings - modern system fonts
    public static final Font HEADER_FONT = new Font("Inter", Font.BOLD, 24);
    public static final Font SUBHEADER_FONT = new Font("Inter", Font.BOLD, 18);
    public static final Font REGULAR_FONT = new Font("Inter", Font.PLAIN, 14);
    public static final Font SMALL_FONT = new Font("Inter", Font.PLAIN, 12);
    public static final Font LOGO_FONT = new Font("Poppins", Font.BOLD, 28);
    public static final Font SIDEBAR_FONT = new Font("Poppins", Font.BOLD, 14);
    public static final Font CARD_TITLE_FONT = new Font("Poppins", Font.ITALIC, 16);
    public static final Font STATS_NUMBER_FONT = new Font("Poppins", Font.BOLD, 24);

    // Table settings - light theme
    public static final Color TABLE_HEADER_COLOR = new Color(243, 244, 246); // Gray-100
    public static final Color TABLE_ROW_COLOR = Color.WHITE;
    public static final Color TABLE_ALTERNATE_ROW_COLOR = new Color(249, 250, 251); // Gray-50
    public static final Color TABLE_BORDER_COLOR = new Color(229, 231, 235); // Gray-200
    public static final int TABLE_ROW_HEIGHT = 40;

    // UI Constants
    public static final int BORDER_RADIUS = 8;
    public static final int BUTTON_RADIUS = 6;
    public static final int PADDING = 12;
    public static final int MARGIN = 24;
    public static final Dimension BUTTON_SIZE = new Dimension(150, 40);
    public static final Dimension SMALL_BUTTON_SIZE = new Dimension(120, 35);
    public static final int SIDEBAR_WIDTH = 250;
    public static final int TITLEBAR_HEIGHT = 60;
    public static final int CARD_RADIUS = 12;
    public static final Dimension CARD_SIZE = new Dimension(300, 150);
    public static final Dimension CHART_SIZE = new Dimension(500, 300);

    // Icons with correct classpath paths
    public static final String DASHBOARD_ICON = "dashboard.svg";
    public static final String BOOK_ICON = "book.svg";
    public static final String LOAN_ICON = "loan.svg";
    public static final String RETURN_ICON = "return.svg";
    public static final String SETTINGS_ICON = "settings.svg";
    public static final String FINE_ICON = "fine.svg";
    public static final String ARCHIVE_ICON = "archive.svg";
    public static final String ADD_ICON = "icons/add.svg";
    public static final String DELETE_ICON = "icons/delete.svg";
    public static final String EDIT_ICON = "icons/edit.svg";
    public static final String LOGOUT_ICON = "icons/logout.svg";
    public static final String REPORTS_ICON = "icons/reports.svg";
    public static final String STATS_ICON = "icons/stats.svg";
    public static final String NOTIFICATION_ICON = "icons/notification.svg";
    public static final String CALENDAR_ICON = "icons/calendar.svg";
    public static final String PRINT_ICON = "icons/print.svg";
    public static final String EXPORT_ICON = "icons/export.svg";
    public static final String MENU_ICON = "icons/menu.svg";
    public static final String CLOSE_ICON = "icons/close.svg";
    public static final String SEARCH_ICON = "icons/close.svg";
}

