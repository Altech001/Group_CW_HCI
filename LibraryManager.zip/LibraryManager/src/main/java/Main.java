import com.formdev.flatlaf.FlatLightLaf;
import controllers.LibrarySystem;
import ui.LibraryUI;
import utils.FileHandler;

import javax.swing.*;

/**
 * Main class to start the Library Management System
 */
public class Main {
    public static void main(String[] args) {
        // Enable native window decorations
        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
        
        // Set up FlatLaf Light theme
        try {
            FlatLightLaf.setup();
        } catch (Exception e) {
            e.printStackTrace();
            // Fallback to system L&F
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        // Create data directory and initial data if needed
        FileHandler.createInitialData();
        
        // Initialize the library system
        LibrarySystem.getInstance().loadData();
        
        // Start the UI
        SwingUtilities.invokeLater(() -> {
            LibraryUI libraryUI = new LibraryUI();
            // Center the window on screen
            libraryUI.setLocationRelativeTo(null);
            libraryUI.setVisible(true);
        });
    }
}
