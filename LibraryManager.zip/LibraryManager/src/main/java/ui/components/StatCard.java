package ui.components;

import utils.Constants;
import utils.IconUtils;

import javax.swing.*;
import java.awt.*;

public class StatCard extends JPanel {
    private final JLabel iconLabel;
    private final JLabel valueLabel;
    private final JLabel titleLabel;
    private final JLabel changeLabel;

    public StatCard(String iconPath, String title) {
        setLayout(new BorderLayout(10, 5));
        setBackground(Constants.CARD_BACKGROUND);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Constants.CARD_BORDER),
            BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));

        // Icon
        iconLabel = new JLabel(IconUtils.loadIcon(iconPath, 24, 24));
        iconLabel.setVerticalAlignment(SwingConstants.TOP);

        // Value and title panel
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBackground(Constants.CARD_BACKGROUND);

        valueLabel = new JLabel("0");
        valueLabel.setFont(Constants.STATS_NUMBER_FONT);
        valueLabel.setForeground(Constants.TEXT_COLOR);

        titleLabel = new JLabel(title);
        titleLabel.setFont(Constants.REGULAR_FONT);
        titleLabel.setForeground(Constants.SECONDARY_TEXT_COLOR);

        // Change indicator
        changeLabel = new JLabel();
        changeLabel.setFont(Constants.SMALL_FONT);
        changeLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        // Layout
        textPanel.add(valueLabel);
        textPanel.add(Box.createVerticalStrut(5));
        textPanel.add(titleLabel);

        add(iconLabel, BorderLayout.WEST);
        add(textPanel, BorderLayout.CENTER);
        add(changeLabel, BorderLayout.SOUTH);

        // Set preferred size
        setPreferredSize(Constants.CARD_SIZE);
    }

    public void setValue(String value) {
        valueLabel.setText(value);
    }

    public void setChangeValue(double percentage) {
        if (percentage > 0) {
            changeLabel.setText("↑ " + String.format("%.1f%%", percentage));
            changeLabel.setForeground(Constants.SUCCESS_COLOR);
        } else if (percentage < 0) {
            changeLabel.setText("↓ " + String.format("%.1f%%", Math.abs(percentage)));
            changeLabel.setForeground(Constants.DANGER_COLOR);
        } else {
            changeLabel.setText("0%");
            changeLabel.setForeground(Constants.SECONDARY_TEXT_COLOR);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw shadow
        g2.setColor(Constants.CARD_SHADOW);
        g2.fillRoundRect(3, 3, getWidth() - 4, getHeight() - 4, Constants.CARD_RADIUS, Constants.CARD_RADIUS);

        // Draw background
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, Constants.CARD_RADIUS, Constants.CARD_RADIUS);

        g2.dispose();
        super.paintComponent(g);
    }
}
