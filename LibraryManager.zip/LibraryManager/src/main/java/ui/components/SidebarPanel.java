package ui.components;

import utils.Constants;
import utils.IconUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class SidebarPanel extends JPanel {
    private int selectedIndex = 0;
    private final List<SidebarItem> items = new ArrayList<>();
    private final JPanel itemsPanel;
    private final SidebarListener listener;

    public interface SidebarListener {
        void onSidebarItemSelected(String itemName, int index);
    }

    public SidebarPanel(SidebarListener listener) {
        this.listener = listener;
        setPreferredSize(new Dimension(Constants.SIDEBAR_WIDTH, 0));
        setBackground(Constants.SIDEBAR_BACKGROUND);
        setLayout(new BorderLayout());

        // Logo panel at the top
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        logoPanel.setBackground(Constants.SIDEBAR_BACKGROUND);
        
        JLabel logoLabel = new JLabel("📚");
        logoLabel.setFont(Constants.LOGO_FONT);
        logoLabel.setForeground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("VU Library MS");
        titleLabel.setFont(Constants.LOGO_FONT);
        titleLabel.setForeground(Color.WHITE);
        
        logoPanel.add(logoLabel);
        logoPanel.add(titleLabel);
        
        // Items panel
        itemsPanel = new JPanel();
        itemsPanel.setBackground(Constants.SIDEBAR_BACKGROUND);
        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));
        
        // Add components
        add(logoPanel, BorderLayout.NORTH);
        add(itemsPanel, BorderLayout.CENTER);
        
        // Add bottom shadow
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 0, 1, Constants.CARD_BORDER),
            BorderFactory.createEmptyBorder(0, 0, 20, 0)
        ));
    }

    public void addItem(String icon, String text) {
        SidebarItem item = new SidebarItem(icon, text, items.size());
        items.add(item);
        itemsPanel.add(item);
        itemsPanel.add(Box.createVerticalStrut(5));
        revalidate();
    }

    public void setSelectedIndex(int index) {
        if (index >= 0 && index < items.size()) {
            items.get(selectedIndex).setSelected(false);
            selectedIndex = index;
            items.get(selectedIndex).setSelected(true);
        }
    }

    private class SidebarItem extends JPanel {
        @SuppressWarnings("unused")
        private final int index;
        private boolean isSelected = false;
        private final Color defaultBackground = Constants.SIDEBAR_BACKGROUND;
        private final Color hoverBackground = Constants.SIDEBAR_HOVER;
        private final Color selectedBackground = Constants.SIDEBAR_ACTIVE;

        public SidebarItem(String iconPath, String text, int index) {
            this.index = index;
            setLayout(new FlowLayout(FlowLayout.LEFT, 20, 12));
            setBackground(defaultBackground);
            setMaximumSize(new Dimension(Constants.SIDEBAR_WIDTH, 50));
            setCursor(new Cursor(Cursor.HAND_CURSOR));

            // Icon
            ImageIcon icon = IconUtils.loadIcon(iconPath, 20, 20);
            JLabel iconLabel = new JLabel(icon);
            iconLabel.setForeground(Color.WHITE);

            // Text
            JLabel textLabel = new JLabel(text);
            textLabel.setFont(Constants.SIDEBAR_FONT);
            textLabel.setForeground(Color.WHITE);

            add(iconLabel);
            add(textLabel);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    if (!isSelected) {
                        setBackground(hoverBackground);
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    if (!isSelected) {
                        setBackground(defaultBackground);
                    }
                }

                @Override
                public void mouseClicked(MouseEvent e) {
                    setSelectedIndex(index);
                    listener.onSidebarItemSelected(text, index);
                }
            });
        }

        public void setSelected(boolean selected) {
            isSelected = selected;
            setBackground(selected ? selectedBackground : defaultBackground);
        }
    }
}
