package ui.components;

import controllers.LoanController;
import models.Loan;
import utils.Constants;
import utils.IconUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ReturnsPanel extends JPanel {
    private final LoanController loanController;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private JTable returnsTable;
    private DefaultTableModel tableModel;

    public ReturnsPanel() {
        this.loanController = LoanController.getInstance();
        setupUI();
        loadReturns();
    }

    private void setupUI() {
        setLayout(new BorderLayout(Constants.PADDING, Constants.PADDING));
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(Constants.PADDING, Constants.PADDING, Constants.PADDING, Constants.PADDING));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Constants.BACKGROUND_COLOR);

        JLabel titleLabel = new JLabel("Recently Returned Books");
        titleLabel.setFont(Constants.CARD_TITLE_FONT);
        titleLabel.setForeground(Constants.TEXT_COLOR);

        JButton archiveButton = new JButton("Archive Selected");
        archiveButton.setIcon(IconUtils.loadIcon(Constants.ARCHIVE_ICON, 16, 16));
        archiveButton.addActionListener(e -> archiveSelectedReturns());

        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(archiveButton, BorderLayout.EAST);

        // Table
        String[] columns = {"Return Date", "Book Title", "Borrower", "Days Late", "Fine"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        returnsTable = new JTable(tableModel);
        IconUtils.styleTable(returnsTable);

        JScrollPane scrollPane = new JScrollPane(returnsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(Constants.CARD_BORDER));
        scrollPane.getViewport().setBackground(Constants.BACKGROUND_COLOR);

        // Add components
        add(headerPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void loadReturns() {
        tableModel.setRowCount(0);
        List<Loan> returnedLoans = loanController.getReturnedLoans();

        for (Loan loan : returnedLoans) {
            long daysLate = 0;
            if (loan.getDueDate() != null && loan.getReturnDate() != null) {
                long diff = loan.getReturnDate().getTime() - loan.getDueDate().getTime();
                daysLate = Math.max(0, TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
            }
            
            Object[] row = {
                dateFormat.format(loan.getReturnDate()),
                loan.getBookTitle(),
                loan.getBorrowerName(),
                daysLate,
                String.format("$%.2f", loan.getFineAmount())
            };
            tableModel.addRow(row);
        }
    }

    private void archiveSelectedReturns() {
        int[] selectedRows = returnsTable.getSelectedRows();
        if (selectedRows.length == 0) {
            JOptionPane.showMessageDialog(this,
                "Please select returns to archive",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to archive " + selectedRows.length + " returned items?",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // TODO: Implement archive functionality
            // This would typically move the selected returns to an archive table/storage
            loadReturns(); // Refresh the table
        }
    }

    public void refresh() {
        loadReturns();
    }
}
