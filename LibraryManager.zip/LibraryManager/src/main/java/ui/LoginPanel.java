package ui;

import controllers.AuthController;
import models.User;
import utils.Constants;
import utils.IconUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;

/**
 * Modern LoginPanel with a clean, light theme design
 */
public class LoginPanel extends JPanel {
    private LibraryUI parentFrame;
    private AuthController authController;
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton forgotPasswordButton;
    private JToggleButton showPasswordButton;
    
    /**
     * Constructor for LoginPanel
     * @param parentFrame The parent frame
     */
    public LoginPanel(LibraryUI parentFrame) {
        this.parentFrame = parentFrame;
        this.authController = AuthController.getInstance();
        
        setupUI();
    }
    
    /**
     * Set up the UI components with modern light theme design
     */
    private void setupUI() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(Constants.MARGIN, Constants.MARGIN, Constants.MARGIN, Constants.MARGIN));
        
        // Create header panel with logo
        JPanel headerPanel = createHeaderPanel();
        
        // Create center panel containing login form
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(Constants.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(Constants.MARGIN, Constants.MARGIN, Constants.MARGIN, Constants.MARGIN);
        
        // Create login form
        JPanel loginFormPanel = createLoginForm();
        centerPanel.add(loginFormPanel, gbc);
        
        // Create footer panel
        JPanel footerPanel = createFooterPanel();
        
        // Add all panels to main panel
        add(headerPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Constants.BACKGROUND_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(Constants.MARGIN, Constants.MARGIN, 0, Constants.MARGIN));
        
        // Logo panel (left side)
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        logoPanel.setBackground(Constants.BACKGROUND_COLOR);
        
        // Create logo
        JLabel logoLabel = new JLabel("📚");
        logoLabel.setFont(Constants.HEADER_FONT.deriveFont(40f));
        logoLabel.setForeground(Constants.PRIMARY_COLOR);
        
        // App title below logo
        JLabel titleLabel = new JLabel(Constants.APP_TITLE);
        titleLabel.setFont(Constants.HEADER_FONT);
        titleLabel.setForeground(Constants.TEXT_COLOR);
        
        // Stack logo and title vertically
        JPanel stackPanel = new JPanel();
        stackPanel.setLayout(new BoxLayout(stackPanel, BoxLayout.Y_AXIS));
        stackPanel.setBackground(Constants.BACKGROUND_COLOR);
        
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        stackPanel.add(logoLabel);
        stackPanel.add(Box.createVerticalStrut(10));
        stackPanel.add(titleLabel);
        
        headerPanel.add(stackPanel, BorderLayout.CENTER);
        
        return headerPanel;
    }

    private JPanel createLoginForm() {
        // Create login panel with card-like appearance
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.Y_AXIS));
        loginPanel.setBackground(Constants.SECONDARY_BACKGROUND);
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Constants.INPUT_BORDER_COLOR),
            BorderFactory.createEmptyBorder(Constants.MARGIN, Constants.MARGIN * 2, Constants.MARGIN, Constants.MARGIN * 2)
        ));
        
        // Welcome header
        JLabel welcomeLabel = new JLabel("Welcome Back");
        welcomeLabel.setFont(Constants.HEADER_FONT);
        welcomeLabel.setForeground(Constants.TEXT_COLOR);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Sign in to your account");
        subtitleLabel.setFont(Constants.REGULAR_FONT);
        subtitleLabel.setForeground(Constants.SECONDARY_TEXT_COLOR);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Username field
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(Constants.REGULAR_FONT);
        usernameLabel.setForeground(Constants.TEXT_COLOR);
        
        usernameField = new JTextField(20);
        usernameField.setFont(Constants.REGULAR_FONT);
        usernameField.setBackground(Constants.BACKGROUND_COLOR);
        usernameField.setForeground(Constants.TEXT_COLOR);
        usernameField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Constants.INPUT_BORDER_COLOR),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        
        // Password field
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(Constants.REGULAR_FONT);
        passwordLabel.setForeground(Constants.TEXT_COLOR);
        
        JPanel passwordPanel = new JPanel(new BorderLayout());
        passwordPanel.setBackground(Constants.BACKGROUND_COLOR);
        
        passwordField = new JPasswordField(20);
        passwordField.setFont(Constants.REGULAR_FONT);
        passwordField.setBackground(Constants.BACKGROUND_COLOR);
        passwordField.setForeground(Constants.TEXT_COLOR);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Constants.INPUT_BORDER_COLOR),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        
        showPasswordButton = new JToggleButton(IconUtils.loadIcon("icons/eye.svg", 16, 16));
        showPasswordButton.setBackground(null);
        showPasswordButton.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 0));
        showPasswordButton.setFocusPainted(false);
        showPasswordButton.addActionListener(e -> {
            passwordField.setEchoChar(showPasswordButton.isSelected() ? '\0' : '•');
        });
        
        passwordPanel.add(passwordField, BorderLayout.CENTER);
        passwordPanel.add(showPasswordButton, BorderLayout.EAST);
        
        // Login button
        loginButton = new JButton("Sign In");
        loginButton.setFont(Constants.REGULAR_FONT);
        loginButton.setBackground(Constants.PRIMARY_COLOR);
        loginButton.setForeground(Color.WHITE);
        loginButton.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        loginButton.setFocusPainted(false);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.addActionListener(e -> handleLogin());
        
        // Add components with proper spacing
        loginPanel.add(Box.createVerticalStrut(Constants.MARGIN));
        loginPanel.add(welcomeLabel);
        loginPanel.add(Box.createVerticalStrut(8));
        loginPanel.add(subtitleLabel);
        loginPanel.add(Box.createVerticalStrut(Constants.MARGIN * 2));
        loginPanel.add(usernameLabel);
        loginPanel.add(Box.createVerticalStrut(8));
        loginPanel.add(usernameField);
        loginPanel.add(Box.createVerticalStrut(Constants.MARGIN));
        loginPanel.add(passwordLabel);
        loginPanel.add(Box.createVerticalStrut(8));
        loginPanel.add(passwordPanel);
        loginPanel.add(Box.createVerticalStrut(Constants.MARGIN * 2));
        loginPanel.add(loginButton);
        loginPanel.add(Box.createVerticalStrut(Constants.MARGIN));
        
        return loginPanel;
    }
    
    /**
     * Create the footer panel with a modern dark mode look
     * @return The footer panel
     */
    private JPanel createFooterPanel() {
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setOpaque(false);
        footerPanel.setBorder(BorderFactory.createEmptyBorder(Constants.PADDING, Constants.MARGIN, Constants.PADDING, Constants.MARGIN));
        
        JLabel copyrightLabel = new JLabel("© 2025 Library Management System");
        copyrightLabel.setFont(Constants.SMALL_FONT);
        copyrightLabel.setForeground(Constants.SECONDARY_TEXT_COLOR);
        
        JPanel linksPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, Constants.PADDING, 0));
        linksPanel.setOpaque(false);
        
        String[] links = {"Help", "Privacy Policy", "Terms of Use"};
        for (String link : links) {
            JButton linkButton = new JButton(link);
            linkButton.setFont(Constants.SMALL_FONT);
            linkButton.setBorderPainted(false);
            linkButton.setContentAreaFilled(false);
            linkButton.setForeground(Constants.ACCENT_COLOR);
            linkButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            linkButton.setFocusPainted(false);
            linkButton.setFocusable(true);
            linkButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    linkButton.setForeground(Constants.ACCENT_COLOR.brighter());
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    linkButton.setForeground(Constants.ACCENT_COLOR);
                }
            });
            linkButton.addActionListener(e -> {
                if (link.equals("Help")) {
                    JOptionPane.showMessageDialog(parentFrame, "Contact support at support@vulibrary.com", "Help", JOptionPane.INFORMATION_MESSAGE);
                } else if (link.equals("Privacy Policy")) {
                    try {
                        Desktop.getDesktop().browse(new URI("https://vulibrary.com/privacy"));
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                } else if (link.equals("Terms of Use")) {
                    try {
                        Desktop.getDesktop().browse(new URI("https://vulibrary.com/terms"));
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });
            linksPanel.add(linkButton);
        }
        
        footerPanel.add(copyrightLabel, BorderLayout.WEST);
        footerPanel.add(linksPanel, BorderLayout.EAST);
        
        return footerPanel;
    }
    
    /**
     * Handle login button click
     */
    private void handleLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(
                parentFrame,
                "Please enter both username and password",
                "Login Error",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        
        User user = authController.login(username, password);
        
        if (user != null) {
            parentFrame.onLoginSuccess(user);
        } else {
            JOptionPane.showMessageDialog(
                parentFrame,
                "Invalid username or password",
                "Login Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    /**
     * Clear the login fields
     */
    public void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        showPasswordButton.setSelected(false);
        passwordField.setEchoChar('•');
        showPasswordButton.setText("👁️");
    }
}