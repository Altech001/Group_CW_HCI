package ui;

import controllers.AuthController;
import controllers.LoanController;
import models.Borrower;
import models.Loan;
import ui.components.BookSearchPanel;
import ui.components.LoanHistoryPanel;
import ui.components.ReturnsPanel;
import ui.components.SidebarPanel;
import ui.components.StatCard;
import utils.Constants;
import utils.IconUtils;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Enhanced BorrowerPanel with modern UI and additional features
 */
public class BorrowerPanel extends JPanel implements SidebarPanel.SidebarListener {
    private LibraryUI parentFrame;
    private AuthController authController;
    private LoanController loanController;
    private Borrower borrower;
    
    private CardLayout contentCardLayout;
    private JPanel contentPanel;
    private BookSearchPanel bookSearchPanel;
    private LoanHistoryPanel loanHistoryPanel;
    private ReturnsPanel returnsPanel;
    private JPanel dashboardPanel;
    
    /**
     * Constructor for BorrowerPanel
     */
    public BorrowerPanel(LibraryUI parentFrame) {
        this.parentFrame = parentFrame;
        this.authController = AuthController.getInstance();
        this.loanController = LoanController.getInstance();
        
        // Get current user, default to a new Borrower if null
        this.borrower = (Borrower) authController.getCurrentUser();
        
        if (this.borrower == null) {
            // Handle the case where there is no authenticated user
            this.borrower = new Borrower(); // Create a placeholder user
            
            // Optionally show an error message or prompt user to log in again
            JOptionPane.showMessageDialog(parentFrame, 
                "You must be logged in to view your account.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            
            // Optionally, navigate to a login screen or show a login prompt
            // loginScreen.setVisible(true);
        }
        
        setupUI();
    }

    
    /**
     * Set up the UI components
     */
    private void setupUI() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        
        // Create sidebar
        SidebarPanel sidebar = new SidebarPanel(this);
        sidebar.addItem(Constants.DASHBOARD_ICON, "Dashboard");
        sidebar.addItem(Constants.BOOK_ICON, "Browse Books");
        sidebar.addItem(Constants.LOAN_ICON, "My Loans");
        sidebar.addItem(Constants.RETURN_ICON, "Returns");
        sidebar.addItem(Constants.SETTINGS_ICON, "Settings");
        sidebar.addItem(Constants.LOGOUT_ICON, "Logout");
        
        // Create content panel with card layout
        contentCardLayout = new CardLayout();
        contentPanel = new JPanel(contentCardLayout);
        contentPanel.setBackground(Constants.BACKGROUND_COLOR);
        
        // Create panels
        createDashboardPanel();
        bookSearchPanel = new BookSearchPanel(parentFrame, true);
        loanHistoryPanel = new LoanHistoryPanel(parentFrame, false);
        loanHistoryPanel.setBorrowerId(borrower.getId()); // Set the borrower ID
        returnsPanel = new ReturnsPanel();
        
        // Add panels to content
        dashboardPanel.setName("Dashboard");
        bookSearchPanel.setName("Browse Books");
        loanHistoryPanel.setName("My Loans");
        returnsPanel.setName("Returns");
        JPanel settingsPanel = createSettingsPanel();
        settingsPanel.setName("Settings");
        
        contentPanel.add(dashboardPanel, "Dashboard");
        contentPanel.add(bookSearchPanel, "Browse Books");
        contentPanel.add(loanHistoryPanel, "My Loans");
        contentPanel.add(returnsPanel, "Returns");
        contentPanel.add(settingsPanel, "Settings");
        
        // Add components to main panel
        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }
    
    private void createDashboardPanel() {
        dashboardPanel = new JPanel();
        dashboardPanel.setBackground(Constants.BACKGROUND_COLOR);
        dashboardPanel.setLayout(new BorderLayout(Constants.PADDING, Constants.PADDING));
        dashboardPanel.setBorder(BorderFactory.createEmptyBorder(
            Constants.PADDING, Constants.PADDING, Constants.PADDING, Constants.PADDING));
        
        // Welcome header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Constants.BACKGROUND_COLOR);
        
        JLabel welcomeLabel = new JLabel("Welcome back, " + 
            (borrower != null ? borrower.getFullName() : "User"));
        welcomeLabel.setFont(Constants.HEADER_FONT);
        welcomeLabel.setForeground(Constants.TEXT_COLOR);
        
        JLabel dateLabel = new JLabel("Today is " + 
            java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("MMMM d, yyyy")));
        dateLabel.setFont(Constants.REGULAR_FONT);
        dateLabel.setForeground(Constants.SECONDARY_TEXT_COLOR);
        
        headerPanel.add(welcomeLabel, BorderLayout.NORTH);
        headerPanel.add(dateLabel, BorderLayout.CENTER);
        
        // Create main content panel with GridBagLayout for flexible arrangement
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(Constants.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        
        // Stats cards panel
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, Constants.PADDING, 0));
        statsPanel.setBackground(Constants.BACKGROUND_COLOR);
        
        // Get actual stats
        List<Loan> activeLoans = loanController.getCurrentLoans(borrower);
        List<Loan> allLoans = loanController.getLoanHistory(borrower);
        double totalFines = loanController.getUnpaidFines(borrower);
        int totalReturned = allLoans.size() - activeLoans.size();
        
        // Books borrowed card
        StatCard booksCard = new StatCard(Constants.BOOK_ICON, "Books Borrowed");
        booksCard.setValue(String.valueOf(allLoans.size()));
        booksCard.setChangeValue(calculateBooksChange(allLoans));
        
        // Active loans card
        StatCard loansCard = new StatCard(Constants.LOAN_ICON, "Active Loans");
        loansCard.setValue(String.valueOf(activeLoans.size()));
        double loanPercentage = borrower.getMaxBooksAllowed() > 0 ? 
            ((double)activeLoans.size() / borrower.getMaxBooksAllowed()) * 100 : 0;
        loansCard.setChangeValue(loanPercentage);
        
        // Books returned card
        StatCard returnsCard = new StatCard(Constants.RETURN_ICON, "Books Returned");
        returnsCard.setValue(String.valueOf(totalReturned));
        returnsCard.setChangeValue(totalReturned > 0 ? 
            ((double)totalReturned / allLoans.size()) * 100 : 0);
        
        // Fines card with warning indicator if fines exist
        StatCard finesCard = new StatCard(Constants.FINE_ICON, "Total Fines");
        finesCard.setValue(String.format("$%.2f", totalFines));
        if (totalFines > 0) {
            finesCard.setChangeValue(-100.0); // Red indicator for existing fines
        } else {
            finesCard.setChangeValue(0.0);
        }
        
        statsPanel.add(booksCard);
        statsPanel.add(loansCard);
        statsPanel.add(returnsCard);
        statsPanel.add(finesCard);
        
        // Add stats panel to content
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, Constants.PADDING, 0);
        contentPanel.add(statsPanel, gbc);
        
        // Due dates panel
        if (!activeLoans.isEmpty()) {
            JPanel dueDatesPanel = new JPanel(new BorderLayout());
            dueDatesPanel.setBackground(Constants.CARD_BACKGROUND);
            dueDatesPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Constants.CARD_BORDER),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
            ));
            
            JLabel dueDatesTitle = new JLabel("Upcoming Due Dates");
            dueDatesTitle.setFont(Constants.CARD_TITLE_FONT);
            dueDatesTitle.setForeground(Constants.TEXT_COLOR);
            
            JPanel duesList = new JPanel();
            duesList.setLayout(new BoxLayout(duesList, BoxLayout.Y_AXIS));
            duesList.setBackground(Constants.CARD_BACKGROUND);
            
            // Create a mutable list and sort it
            List<Loan> sortedLoans = new ArrayList<>(activeLoans);
            Collections.sort(sortedLoans, (a, b) -> a.getDueDate().compareTo(b.getDueDate()));
            
            for (int i = 0; i < Math.min(3, sortedLoans.size()); i++) {
                Loan loan = sortedLoans.get(i);
                String title = loan.getBookTitle();
                String dueDate = new SimpleDateFormat("MMM d, yyyy").format(loan.getDueDate());
                long daysLeft = java.time.temporal.ChronoUnit.DAYS.between(
                    java.time.LocalDate.now(),
                    loan.getDueDate().toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                );
                
                JPanel itemPanel = new JPanel(new BorderLayout());
                itemPanel.setBackground(Constants.CARD_BACKGROUND);
                itemPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
                
                JLabel bookLabel = new JLabel(title);
                bookLabel.setFont(Constants.REGULAR_FONT);
                
                JLabel dueDateLabel = new JLabel(dueDate);
                dueDateLabel.setFont(Constants.SMALL_FONT);
                dueDateLabel.setForeground(
                    daysLeft < 3 ? Constants.DANGER_COLOR :
                    daysLeft < 7 ? Color.ORANGE :
                    Constants.SECONDARY_TEXT_COLOR
                );
                
                itemPanel.add(bookLabel, BorderLayout.WEST);
                itemPanel.add(dueDateLabel, BorderLayout.EAST);
                duesList.add(itemPanel);
            }
            
            dueDatesPanel.add(dueDatesTitle, BorderLayout.NORTH);
            dueDatesPanel.add(duesList, BorderLayout.CENTER);
            
            // Add due dates panel to content
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            gbc.weightx = 1.0;
            gbc.fill = GridBagConstraints.BOTH;
            contentPanel.add(dueDatesPanel, gbc);
        }
        
        // Add all components to main panel
        dashboardPanel.add(headerPanel, BorderLayout.NORTH);
        dashboardPanel.add(contentPanel, BorderLayout.CENTER);
    }

    private double calculateBooksChange(List<Loan> allLoans) {
        // Calculate the percentage change in borrowing activity
        int recentLoans = 0;
        int previousLoans = 0;
        java.time.LocalDate now = java.time.LocalDate.now();
        
        for (Loan loan : allLoans) {
            java.time.LocalDate loanDate = loan.getCheckoutDate().toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();
            
            if (loanDate.isAfter(now.minusMonths(1))) {
                recentLoans++;
            } else if (loanDate.isAfter(now.minusMonths(2))) {
                previousLoans++;
            }
        }
        
        if (previousLoans == 0) return 0;
        return ((double)(recentLoans - previousLoans) / previousLoans) * 100;
    }
    
    private JPanel createSettingsPanel() {
        JPanel settingsPanel = new JPanel(new BorderLayout(Constants.PADDING, Constants.PADDING));
        settingsPanel.setBackground(Constants.BACKGROUND_COLOR);
        settingsPanel.setBorder(BorderFactory.createEmptyBorder(
            Constants.PADDING, Constants.PADDING, Constants.PADDING, Constants.PADDING));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Constants.BACKGROUND_COLOR);
        
        JLabel titleLabel = new JLabel("Settings");
        titleLabel.setFont(Constants.HEADER_FONT);
        titleLabel.setForeground(Constants.TEXT_COLOR);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Main settings content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(Constants.BACKGROUND_COLOR);

        // Profile section
        JPanel profilePanel = new JPanel(new BorderLayout());
        profilePanel.setBackground(Constants.CARD_BACKGROUND);
        profilePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Constants.CARD_BORDER),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel profileTitle = new JLabel("Profile Information");
        profileTitle.setFont(Constants.CARD_TITLE_FONT);

        // Profile form
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Constants.CARD_BACKGROUND);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 10);
        
        // Full Name
        addFormField(formPanel, gbc, "Full Name:", borrower.getFullName(), 0);
        
        // User ID / Library Card
        addFormField(formPanel, gbc, "User ID:", borrower.getId(), 1);
        
        // Email
        addFormField(formPanel, gbc, "Email:", borrower.getEmail(), 2);
        
        // Phone
        addFormField(formPanel, gbc, "Phone:", borrower.getPhone(), 3);
        
        // Address
        addFormField(formPanel, gbc, "Address:", borrower.getAddress(), 4);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Constants.CARD_BACKGROUND);
        
        JButton editButton = IconUtils.createStyledButton("Edit Profile", Constants.EDIT_ICON, Constants.BUTTON_SIZE);
        editButton.addActionListener(e -> showEditProfileDialog());
        buttonPanel.add(editButton);

        profilePanel.add(profileTitle, BorderLayout.NORTH);
        profilePanel.add(formPanel, BorderLayout.CENTER);
        profilePanel.add(buttonPanel, BorderLayout.SOUTH);

        // Account Status section
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBackground(Constants.CARD_BACKGROUND);
        statusPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Constants.CARD_BORDER),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel statusTitle = new JLabel("Account Status");
        statusTitle.setFont(Constants.CARD_TITLE_FONT);

        JPanel statusContent = new JPanel(new GridBagLayout());
        statusContent.setBackground(Constants.CARD_BACKGROUND);
        
        // Maximum books allowed
        addFormField(statusContent, gbc, "Maximum Books:", 
            String.valueOf(borrower.getMaxBooksAllowed()), 0);
        
        // Current loans
        List<Loan> currentLoans = loanController.getCurrentLoans(borrower);
        addFormField(statusContent, gbc, "Current Loans:", 
            String.valueOf(currentLoans.size()), 1);

        // Account status
        String status = currentLoans.size() >= borrower.getMaxBooksAllowed() ? "Borrowing Limit Reached" : "Active";
        addFormField(statusContent, gbc, "Status:", status, 2);

        statusPanel.add(statusTitle, BorderLayout.NORTH);
        statusPanel.add(statusContent, BorderLayout.CENTER);

        // Add sections to content
        contentPanel.add(profilePanel);
        contentPanel.add(Box.createVerticalStrut(Constants.PADDING));
        contentPanel.add(statusPanel);

        // Add all components
        settingsPanel.add(headerPanel, BorderLayout.NORTH);
        settingsPanel.add(contentPanel, BorderLayout.CENTER);

        return settingsPanel;
    }

    private void showEditProfileDialog() {
        JDialog dialog = new JDialog(parentFrame, "Edit Profile", true);
        dialog.setLayout(new BorderLayout());
        dialog.setSize(400, 400);
        dialog.setLocationRelativeTo(parentFrame);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);
        gbc.gridwidth = 1;

        // Create form fields
        JTextField nameField = createFormField("Full Name:", borrower.getFullName(), formPanel, gbc, 0);
        JTextField emailField = createFormField("Email:", borrower.getEmail(), formPanel, gbc, 1);
        JTextField phoneField = createFormField("Phone:", borrower.getPhone(), formPanel, gbc, 2);
        JTextField addressField = createFormField("Address:", borrower.getAddress(), formPanel, gbc, 3);

        // Create button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        saveButton.addActionListener(e -> {
            // Validate input
            if (nameField.getText().trim().isEmpty() || emailField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(dialog, 
                    "Name and email are required fields.", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Update borrower information
            borrower.setFullName(nameField.getText().trim());
            borrower.setEmail(emailField.getText().trim());
            borrower.setPhone(phoneField.getText().trim());
            borrower.setAddress(addressField.getText().trim());

            // Save changes and refresh UI
            if (authController.updateUser(borrower)) {
                refreshData();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, 
                    "Failed to update profile. Please try again.", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, String label, String value, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.3;
        JLabel fieldLabel = new JLabel(label);
        fieldLabel.setFont(Constants.REGULAR_FONT);
        panel.add(fieldLabel, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        JTextField field = new JTextField(value);
        field.setEditable(false);
        field.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        field.setBackground(Constants.SECONDARY_BACKGROUND);
        panel.add(field, gbc);
    }

    private JTextField createFormField(String label, String value, JPanel panel, GridBagConstraints gbc, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.3;
        JLabel fieldLabel = new JLabel(label);
        fieldLabel.setFont(Constants.REGULAR_FONT);
        panel.add(fieldLabel, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        JTextField field = new JTextField(value, 20);
        panel.add(field, gbc);
        return field;
    }
    
    /**
     * Helper method to find a component by name in a container
     */
    private Component findComponentByName(Container container, String name) {
        Component[] components = container.getComponents();
        for (Component component : components) {
            if (name.equals(component.getName())) {
                return component;
            }
        }
        return null;
    }
    
    @Override
    public void onSidebarItemSelected(String itemName, int index) {
        if ("Logout".equals(itemName)) {
            authController.logout();
            parentFrame.onLogout();
            return;
        }
        contentCardLayout.show(contentPanel, itemName);
    }
    
    /**
     * Refresh data in all panels
     */
    public void refreshData() {
        // Reload the current user to get fresh data
        this.borrower = (Borrower) authController.getCurrentUser();
        
        // Update all panels with fresh data
        bookSearchPanel.refreshData();
        loanHistoryPanel.setBorrowerId(borrower.getId());
        loanHistoryPanel.refreshData();
        returnsPanel.refresh();
        
        // Remove old dashboard and create new one with updated stats
        contentPanel.remove(dashboardPanel);
        createDashboardPanel();
        contentPanel.add(dashboardPanel, "Dashboard");
        
        // Refresh settings panel
        JPanel newSettingsPanel = createSettingsPanel();
        newSettingsPanel.setName("Settings");
        contentPanel.remove(findComponentByName(contentPanel, "Settings"));
        contentPanel.add(newSettingsPanel, "Settings");
        
        // Get all panel names we added
        String[] panelNames = {"Dashboard", "Browse Books", "My Loans", "Returns", "Settings"};
        
        // Find currently visible panel by checking each component's visibility
        for (String panelName : panelNames) {
            Component comp = findComponentByName(contentPanel, panelName);
            if (comp != null && comp.isVisible()) {
                ((CardLayout)contentPanel.getLayout()).show(contentPanel, panelName);
                break;
            }
        }
    }
}
