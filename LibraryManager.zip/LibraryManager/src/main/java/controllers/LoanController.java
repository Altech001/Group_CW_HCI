package controllers;

import models.Loan;
import models.Fine;
import models.Borrower;
import utils.Constants;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for handling loan operations
 */
public class LoanController {
    private static LoanController instance;
    private LibrarySystem librarySystem;
    
    private LoanController() {
        librarySystem = LibrarySystem.getInstance();
    }
    
    /**
     * Get the singleton instance
     * @return The LoanController instance
     */
    public static LoanController getInstance() {
        if (instance == null) {
            instance = new LoanController();
        }
        return instance;
    }
    
    /**
     * Get current active loans for a borrower
     */
    public List<Loan> getCurrentLoans(Borrower borrower) {
        if (borrower == null) return List.of();
        return librarySystem.getActiveLoansForBorrower(borrower.getId());
    }
    
    /**
     * Get all loans (loan history) for a borrower
     */
    public List<Loan> getLoanHistory(Borrower borrower) {
        if (borrower == null) return List.of();
        return librarySystem.getLoanHistoryForBorrower(borrower.getId());
    }
    
    /**
     * Get loan history for a specific borrower
     * @param borrowerId The ID of the borrower
     * @return List of all loans for the borrower
     */
    public List<Loan> getLoanHistoryForBorrower(String borrowerId) {
        return librarySystem.getLoanHistoryForBorrower(borrowerId);
    }

    /**
     * Get total unpaid fines for a borrower
     */
    public double getUnpaidFines(Borrower borrower) {
        if (borrower == null) return 0.0;
        return librarySystem.getUnpaidFinesForBorrower(borrower.getId())
            .stream()
            .mapToDouble(Fine::getAmount)
            .sum();
    }

    /**
     * Get all loans
     */
    public List<Loan> getAllLoans() {
        return librarySystem.getAllLoans();
    }
    
    /**
     * Get a loan by ID
     */
    public Loan getLoanById(String loanId) {
        return librarySystem.getLoanById(loanId);
    }
    
    /**
     * Create a new loan (checkout a book)
     */
    public Loan createLoan(String bookId, String borrowerId) {
        return librarySystem.createLoan(bookId, borrowerId, Constants.LOAN_DURATION_DAYS);
    }
    
    /**
     * Return a book (check in)
     */
    public boolean returnBook(String loanId) {
        return librarySystem.returnBook(loanId);
    }
    
    /**
     * Get all fines
     */
    public List<Fine> getAllFines() {
        return librarySystem.getAllFines();
    }
    
    /**
     * Get a fine by ID
     */
    public Fine getFineById(String fineId) {
        return librarySystem.getFineById(fineId);
    }
    
    /**
     * Pay a fine
     */
    public boolean payFine(String fineId) {
        return librarySystem.payFine(fineId);
    }
    
    /**
     * Get all fines for a specific borrower
     */
    public List<Fine> getFinesForBorrower(String borrowerId) {
        return librarySystem.getFinesForBorrower(borrowerId);
    }
    
    /**
     * Get all unpaid fines for a borrower
     */
    public List<Fine> getUnpaidFinesForBorrower(String borrowerId) {
        return librarySystem.getUnpaidFinesForBorrower(borrowerId);
    }
    
    /**
     * Record a fine for a borrower
     */
    public Fine recordFine(String loanId, double amount, String reason) {
        Loan loan = librarySystem.getLoanById(loanId);
        
        if (loan == null) {
            return null;
        }
        
        Fine fine = new Fine(loanId, loan.getBorrowerId(), amount, reason);
        fine.setBorrowerName(loan.getBorrowerName());
        fine.setBookTitle(loan.getBookTitle());
        
        // Add fine and update loan
        loan.setFineAmount(amount);
        
        List<Fine> fines = librarySystem.getAllFines();
        fines.add(fine);
        
        librarySystem.saveData();
        
        return fine;
    }
    
    /**
     * Check if a loan is overdue
     */
    public boolean isLoanOverdue(String loanId) {
        Loan loan = librarySystem.getLoanById(loanId);
        return loan != null && loan.isOverdue();
    }
    
    /**
     * Get all returned loans
     * @return List of returned loans
     */
    public List<Loan> getReturnedLoans() {
        return getAllLoans().stream()
                .filter(Loan::isReturned)
                .collect(Collectors.toList());
    }
}
