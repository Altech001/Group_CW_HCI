package controllers;

import models.Book;
import models.Borrower;
import models.Loan;
import models.Fine;
import org.junit.Before;
import org.junit.Test;
import java.util.Date;
import java.util.List;
import static org.junit.Assert.*;

/**
 * Test class for LoanController functionality
 */
public class LoanControllerTest {
    private LoanController loanController;
    private LibrarySystem librarySystem;
    private Book testBook;
    private Borrower testBorrower;

    @Before
    public void setUp() {
        // Get instances
        loanController = LoanController.getInstance();
        librarySystem = LibrarySystem.getInstance();

        // Create test data
        testBook = new Book("Test Book", "Test Author", "General", 1);
        librarySystem.addBook(testBook);

        testBorrower = new Borrower("testuser", "password", "Test User", "test@email.com", "123-456-7890", "Test Address", "B12345");
        librarySystem.addUser(testBorrower);
    }

    @Test
    public void testCreateLoan() {
        // Test loan creation
        Loan loan = loanController.createLoan(testBook.getId(), testBorrower.getId());
        assertNotNull("Loan should be created successfully", loan);
        assertEquals("Book ID should match", testBook.getId(), loan.getBookId());
        assertEquals("Borrower ID should match", testBorrower.getId(), loan.getBorrowerId());
        assertFalse("Loan should not be returned initially", loan.isReturned());
    }

    @Test
    public void testReturnBook() {
        // Create a loan first
        Loan loan = loanController.createLoan(testBook.getId(), testBorrower.getId());
        String loanId = loan.getId();

        // Test return
        boolean returned = loanController.returnBook(loanId);
        assertTrue("Book should be returned successfully", returned);

        // Verify return status
        loan = loanController.getLoanById(loanId);
        assertNotNull("Loan should still exist", loan);
        assertTrue("Loan should be marked as returned", loan.isReturned());
        assertNotNull("Return date should be set", loan.getReturnDate());
    }

    @Test
    public void testGetCurrentLoans() {
        // Create a loan
        loanController.createLoan(testBook.getId(), testBorrower.getId());

        // Test getting current loans
        List<Loan> currentLoans = loanController.getCurrentLoans(testBorrower);
        assertNotNull("Current loans list should not be null", currentLoans);
        assertFalse("Current loans list should not be empty", currentLoans.isEmpty());
        assertEquals("Should have one current loan", 1, currentLoans.size());
    }

    @Test
    public void testLoanHistory() {
        // Create a loan and return it
        Loan loan = loanController.createLoan(testBook.getId(), testBorrower.getId());
        loanController.returnBook(loan.getId());

        // Test getting loan history
        List<Loan> loanHistory = loanController.getLoanHistory(testBorrower);
        assertNotNull("Loan history should not be null", loanHistory);
        assertFalse("Loan history should not be empty", loanHistory.isEmpty());
        assertTrue("Loan history should contain the returned loan", 
            loanHistory.stream().anyMatch(l -> l.getId().equals(loan.getId())));
    }

    @Test
    public void testOverdueLoan() {
        // Create a loan with manipulation of dates to simulate overdue
        Loan loan = loanController.createLoan(testBook.getId(), testBorrower.getId());

        // Check if loan is overdue
        boolean isOverdue = loanController.isLoanOverdue(loan.getId());
        assertFalse("New loan should not be overdue", isOverdue);

        // We'd need to mock dates or use a clock service for proper overdue testing
        // This is just a basic check of the functionality
    }
}
